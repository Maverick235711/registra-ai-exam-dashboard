# Registra AI — India-Wide Competitive & Entrance Exam Database

**Reference Date (build date, not a verification date):** `2026-11-15` (Sunday, November 15, 2026)  
**Examinations Catalogued:** `90` (all currently **unverified** against fetched official documents) across 12 National & State Categories  
**Schema Format:** Normalized Relational JSON (ISO 8601 dates, strict `null` handling, zero trailing commas, zero inline comments)

---

## 1. Database Architecture & Entity-Relationship Overview

```
+-------------------+       1:N       +-----------------------+
|    exams.json     |---------------->|   exam_cycles.json    |
|  (PK: exam_id)    |                 | (PK: cycle_id)        |
+-------------------+                 +-----------------------+
        |   |   |   |
        |   |   |   +--- 1:N -------->+-----------------------+
        |   |   |                     | exam_eligibility.json |
        |   |   |                     | (PK: eligibility_id)  |
        |   |   |                     +-----------------------+
        |   |   |
        |   |   +------- 1:N -------->+-----------------------+
        |   |                         |    exam_fees.json     |
        |   |                         |   (PK: fee_id)        |
        |   |                         +-----------------------+
        |   |
        |   +----------- 1:N -------->+-----------------------+
        |                             |  exam_documents.json  |
        |                             | (PK: document_req_id) |
        |                             +-----------------------+
        |
        +--- 1:1 -------------------->+----------------------------+
        |                             | exam_registration_steps.json|
        |                             | (PK: registration_flow_id) |
        |                             +----------------------------+
        |
        +--- 1:N -------------------->+-----------------------+
                                      |   exam_stages.json    |
                                      | (PK: stage_schema_id) |
                                      +-----------------------+

Cross-Cutting Governance Tables:
- exam_sources.json      (PK: source_id, M:N via exam_ids[])
- unverified_fields.json (PK: audit_id, FK: exam_id, table_name, record_id)
```

---

## 2. Dataset Inventory & Record Counts

| File | Primary Key | Foreign Key(s) | Record Count | Purpose |
| :--- | :--- | :--- | :---: | :--- |
| `exams.json` | `exam_id` | `source_ids[]` | 90 | Master exam registry, conducting authorities, canonical URLs, status |
| `exam_cycles.json` | `cycle_id` | `exam_id` | 182 | Session/cycle-level schedules (18 milestone date objects per cycle) |
| `exam_eligibility.json` | `eligibility_id` | `exam_id` | 90 | Age limits, qualifications, streams, min marks, relaxations, attempts |
| `exam_fees.json` | `fee_id` | `exam_id` | 90 | Category-wise fee matrix (`General`, `OBC`, `EWS`, `SC`, `ST`, `PwD`, `Female`) |
| `exam_documents.json` | `document_req_id` | `exam_id` | 305 | Portal-specific upload rules (formats, KB bounds, pixel dimensions, validity) |
| `exam_registration_steps.json` | `registration_flow_id` | `exam_id` | 90 | Step-by-step registration workflow, OTR/Aadhaar/DigiLocker/Live Photo flags |
| `exam_stages.json` | `stage_schema_id` | `exam_id` | 90 | Exam mode, stages, papers, marks, duration, negative marking, counselling |
| `exam_sources.json` | `source_id` | `exam_ids[]` | 57 | Official homepage URL registry (homepages not yet fetched; `supported_fields` is empty until verified) |
| `unverified_fields.json` | `audit_id` | `exam_id`, `record_id` | 467 | Explicit tracker of unannounced 2027 dates & cycle-dependent specs |

---

## 3. Category Coverage (90 Distinct Examinations — Zero Duplication)

- **A. Engineering & Technology (15):** `JEE_MAIN`, `JEE_ADV`, `BITSAT`, `VITEEE`, `SRMJEEE`, `MET`, `COMEDK_UGET`, `WBJEE`, `MHT_CET`, `KCET`, `AP_EAPCET`, `TG_EAPCET`, `GUJCET`, `OJEE`, `GATE`
- **B. Medical & Healthcare (9):** `NEET_UG`, `NEET_PG` *(NBEMS)*, `INI_CET` *(AIIMS)*, `NEET_MDS` *(NBEMS)*, `NEET_SS` *(NBEMS)*, `FMGE` *(NBEMS)*, `AIAPGET` *(NTA)*, `AIIMS_BSC_NURSING` *(AIIMS)*, `NEXT_MEDICAL` *(NMC — Status: `Awaiting Notification`)*
- **C. Railway Recruitment (9):** `RRB_NTPC_GRAD`, `RRB_NTPC_UG`, `RRB_ALP`, `RRB_JE`, `RRB_TECHNICIAN`, `RRB_GROUP_D`, `RPF_SI`, `RPF_CONSTABLE`, `RRB_PARAMEDICAL`
- **D. UPSC & Civil Services (6):** `UPSC_CSE`, `UPSC_IFOS`, `UPSC_ESE`, `UPSC_CAPF_AC` *(cross-tagged `Defence`)*, `UPSC_NDA_NA` *(cross-tagged `Defence`)*, `UPSC_CDS` *(cross-tagged `Defence`)*
- **E. SSC & Government Recruitment (7):** `SSC_CGL`, `SSC_CHSL`, `SSC_MTS`, `SSC_GD`, `SSC_CPO`, `SSC_JE`, `SSC_STENO`
- **F. Banking & Finance (10):** `IBPS_PO`, `IBPS_CLERK`, `IBPS_SO`, `IBPS_RRB_OFFICER`, `IBPS_RRB_OA`, `SBI_PO`, `SBI_CLERK`, `RBI_GRADE_B`, `RBI_ASSISTANT`, `LIC_AAO`
- **G. Defence (5 non-duplicate + 3 cross-tagged from UPSC):** `IAF_AFCAT`, `INDIAN_ARMY_AGNIVEER`, `INDIAN_NAVY_AGNIVEER`, `IAF_AGNIVEERVAYU`, `ICG_CGEPT`
- **H. Management & Business (8):** `CAT`, `XAT`, `CMAT`, `MAT`, `SNAP`, `NMAT`, `ATMA`, `MAH_MBA_CET`
- **I. Law (4):** `CLAT_UG`, `CLAT_PG`, `AILET`, `SLAT`
- **J. University & General Entrance (6):** `CUET_UG`, `CUET_PG`, `NEST`, `IISER_IAT`, `JIPMAT`, `IIT_JAM`
- **K. Teaching & Eligibility (6):** `CTET`, `UGC_NET`, `CSIR_UGC_NET`, `MAHA_TET`, `MH_SET`, `KVS_RECRUITMENT`
- **L. Architecture, Design & Other Professional Exams (5):** `NATA`, `UCEED`, `CEED`, `NID_DAT`, `NIFTEE`

---

## 4. Controlled Vocabularies & Data Governance Rules

1. **No Date Fabrication, No False Verification:** No dates are populated yet. Each date has `date_value: null` and `date_status` of `"Not Checked"`, `"Not Found In Fetched Documents"` or `"Verified from Official Document"` (the last only with `evidence_snippet` and `source_sha256`). `last_verified_at` is null unless evidence was matched.
2. **Controlled Enums:**
   - `exam_level`: `"National"` | `"State"` | `"University"` | `"Institutional"`
   - `exam_type`: `"Entrance"` | `"Recruitment"` | `"Eligibility"` | `"Professional"`
   - `frequency`: `"Annual"` | `"Multiple times a year"` | `"Irregular"` | `"As notified"`
   - `current_status`: `"Active"` | `"Upcoming"` | `"Application Open"` | `"Application Closed"` | `"Awaiting Notification"` | `"Discontinued"` | `"Unverified"`
   - `date_status`: `"Confirmed"` | `"Tentative"` | `"Expected"` | `"Not Announced"` | `"Not Applicable"`
   - `date_precision`: `"Exact"` | `"Month Only"` | `"Date Range"` | `"Unknown"`
   - `examination_mode`: `"Online"` | `"Offline"` | `"Both"`
3. **Referential Integrity:** Every foreign key (`exam_id`, `source_ids`) has been programmatically verified against `exams.json` and `exam_sources.json`.

---

## 5. Integration Guide for Registra AI

1. **Seed Ingestion:** Import `exams.json` and `exam_sources.json` first into PostgreSQL (`JSONB` columns or normalized relational tables) or MongoDB.
2. **Child Table Hydration:** Upsert `exam_cycles.json`, `exam_eligibility.json`, `exam_fees.json`, `exam_documents.json`, `exam_registration_steps.json`, and `exam_stages.json` keyed on their respective primary keys.
3. **Automated Scraper / Notification Watcher:** Use `unverified_fields.json` (`recommended_monitoring_url` + `reason_code`) as the priority queue for Registra AI's official notification ingestion pipeline. When a 2027 notification PDF is published, update `date_value`, use `registra_verification.py` (or add a `"origin": "manual"` entry in `_date_registry.json`), and resolve the corresponding `audit_id` entry.


---

## Verification Status & Pipeline

This snapshot has **0 of 3,276** milestone dates populated and **0** fields matched against fetched official documents.
Fees, ages, marks and stages were entered from prior knowledge and are labelled `Not Checked`; document specs and registration steps are
generic templates (`TEMPLATED_UNVERIFIED`).

To verify: put the exam master list in `exams_data.py` and run `python registra_verification.py run`. It fetches official pages and
linked notification PDFs, stores hashes, extracts dates with evidence lines, matches fees/age/marks against the text, writes
`_date_registry.json`, `_verification_report.json` and `_date_review_queue.json`, and the build then reads them via
`date_object`, `field_verification`, `last_verified`, `build_source_records`.
