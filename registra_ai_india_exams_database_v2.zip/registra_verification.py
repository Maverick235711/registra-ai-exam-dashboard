"""
registra_verification.py

Fixes two problems in the Registra AI build script:
  1. Dates were never populated (every milestone was null / "Not Announced").
  2. "Sources" were just homepage URLs, labelled as proof for every field.

How it works
  * `run` fetches each exam's official pages, follows links to notification /
    bulletin / schedule documents (PDF or HTML), snapshots them (SHA-256), and:
      - extracts milestone dates WITH the exact text line they came from,
      - checks whether each stored fee / age / marks value actually appears in
        a fetched document, near the right keywords.
  * Dates are auto-accepted only under strict rules; everything else goes to
    `_date_review_queue.json` for a human. Nothing is ever guessed.
  * The build script reads `_date_registry.json` and `_verification_report.json`
    instead of stamping REF_DATE on everything.

Usage
    python registra_verification.py run                 # all exams
    python registra_verification.py run JEE_MAIN CAT    # selected exams

Requires: requests, beautifulsoup4, and pdfplumber (or pypdf).
Expects EXAMS_DATA in exams_data.py (move the list out of the build script).

Manual overrides: add an entry to _date_registry.json with "origin": "manual".
Manual entries are never overwritten by automatic runs.
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse

OUT = Path("registra_ai_database")
SNAP = OUT / "_snapshots"
REPORT_PATH = OUT / "_verification_report.json"
REGISTRY_PATH = OUT / "_date_registry.json"
REVIEW_PATH = OUT / "_date_review_queue.json"

HEADERS = {"User-Agent": "RegistraAI-Verifier/1.0"}
CRAWL_DELAY = 1.5
MAX_LINKED_DOCS = 8
LINK_HINTS = ("notification", "notice", "bulletin", "brochure", "schedule",
              "advertisement", "advt", "information", "calendar",
              "important dates", "scheme of exam")

DATE_FIELDS = [
    "official_notification_release", "application_form_start",
    "application_last_date", "fee_payment_last_date",
    "application_correction_window_start", "application_correction_window_end",
    "admit_card_release", "exam_city_intimation_slip", "exam_date_start",
    "exam_date_end", "answer_key_release", "objection_challenge_window_start",
    "objection_challenge_window_end", "result_declaration", "counselling_start",
    "counselling_last_date", "document_verification",
    "admission_or_joining_deadline",
]
# Labels that are too noisy to auto-accept ("result" appears everywhere).
REVIEW_ALWAYS = {"result_declaration", "admission_or_joining_deadline",
                 "counselling_start", "counselling_last_date",
                 "document_verification", "official_notification_release"}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _load(path: Path, default):
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default


def _save(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Fetching
# ---------------------------------------------------------------------------
def _pdf_text(raw: bytes) -> str:
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(raw)) as pdf:
            return "\n".join((p.extract_text() or "") for p in pdf.pages)
    except ImportError:
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(raw)).pages)


def fetch_doc(url: str):
    """Returns (record, text, links). Never raises; failures are recorded."""
    import requests
    from bs4 import BeautifulSoup

    rec = {"requested_url": url, "key": url, "fetched_at": _now(), "http_status": None,
           "final_url": None, "content_type": None, "sha256": None,
           "doc_type": None, "text_chars": 0, "error": None}
    try:
        r = requests.get(url, headers=HEADERS, timeout=30, allow_redirects=True)
        rec.update(http_status=r.status_code, final_url=r.url,
                   content_type=r.headers.get("content-type", "").lower())
        if r.status_code != 200:
            rec["error"] = f"HTTP {r.status_code}"
            return rec, "", []
        raw = r.content
        rec["sha256"] = hashlib.sha256(raw).hexdigest()
        links = []
        if "pdf" in rec["content_type"] or r.url.lower().split("?")[0].endswith(".pdf"):
            rec["doc_type"] = "PDF_DOCUMENT"
            text = _pdf_text(raw)
        else:
            soup = BeautifulSoup(raw, "html.parser")
            links = [(a.get_text(" ", strip=True), urljoin(r.url, a["href"]))
                     for a in soup.find_all("a", href=True)]
            for t in soup(["script", "style", "noscript"]):
                t.decompose()
            text = soup.get_text("\n")
            path = urlparse(r.url).path.strip("/").lower()
            home = path in {"", "index.html", "index.php", "index.aspx", "home"}
            rec["doc_type"] = "HOMEPAGE" if home else "HTML_PAGE"
        rec["text_chars"] = len(text)
        if not text.strip():
            rec["error"] = "NO_EXTRACTABLE_TEXT (scanned PDF or JS-rendered page)"
        else:
            SNAP.mkdir(parents=True, exist_ok=True)
            (SNAP / f"{rec['sha256'][:16]}.txt").write_text(text, encoding="utf-8")
        return rec, text, links
    except Exception as exc:  # network / parse errors must not kill the batch
        rec["error"] = f"{type(exc).__name__}: {exc}"
        return rec, "", []


def _cycle_years(ex) -> list[int]:
    ys = [int(y) for y in re.findall(r"20\d{2}", ex["applicable_academic_year_or_recruitment_cycle"])]
    return ys or [datetime.now().year, datetime.now().year + 1]


def gather_documents(ex):
    """Fetch seed pages, then follow the most promising notification links."""
    seeds = sorted({u for u in (ex.get("official_notification_url"),
                                ex.get("official_information_brochure_url"),
                                ex.get("official_registration_url"),
                                ex.get("official_exam_website")) if u})
    years = [str(y) for y in _cycle_years(ex)]
    docs, texts, seen, candidates = [], {}, set(), []
    for seed in seeds:
        if seed in seen:
            continue
        seen.add(seed)
        rec, text, links = fetch_doc(seed)
        docs.append(rec)
        texts[rec["key"]] = text
        time.sleep(CRAWL_DELAY)
        for label, href in links:
            blob = f"{label} {href}".lower()
            if any(h in blob for h in LINK_HINTS):
                score = 2 * any(y in blob for y in years) + href.lower().split("?")[0].endswith(".pdf")
                candidates.append((score, href))
    for _, href in sorted(candidates, key=lambda x: -x[0]):
        if len(docs) >= len(seeds) + MAX_LINKED_DOCS:
            break
        if href in seen or not href.startswith("http"):
            continue
        seen.add(href)
        rec, text, _ = fetch_doc(href)
        docs.append(rec)
        texts[rec["key"]] = text
        time.sleep(CRAWL_DELAY)
    return docs, texts


# ---------------------------------------------------------------------------
# Field verification (fees / age / marks / stages)
# ---------------------------------------------------------------------------
FEE_KW = ("fee", "fees", "rs.", "rs ", "inr", "₹", "payment")


def _amount_tokens(n: int) -> list[str]:
    return [f"{n:,}", str(n)] if n >= 1000 else [str(n)]


def _find_near(text: str, token: str, keywords, window: int = 120):
    pat = re.compile(rf"(?<![\d,]){re.escape(token)}(?![\d])")
    low = text.lower()
    for m in pat.finditer(text):
        a, b = max(0, m.start() - window), m.end() + window
        if any(k in low[a:b] for k in keywords):
            return " ".join(text[a:b].split())
    return None


def _expected(ex):
    fee_vals = sorted({v for v in ex["fees"].values() if isinstance(v, int) and v > 0})
    ages = [a for a in (ex["min_age"], ex["max_age"]) if a]
    pcts = sorted({int(p) for s in (ex["min_marks"]["general_obc_ews"], ex["min_marks"]["sc_st_pwd"])
                   for p in re.findall(r"(\d{2,3})\s*%", s)})
    marks = sorted({int(m) for m in re.findall(r"\d{2,4}", str(ex["total_marks"]))})
    return {
        "fees": ([(f"INR {v}", _amount_tokens(v)) for v in fee_vals], FEE_KW),
        "eligibility_age": ([(f"age {a}", [str(a)]) for a in ages], ("age", "years")),
        "eligibility_marks": ([(f"{p}%", [str(p)]) for p in pcts], ("%", "percent", "marks", "aggregate")),
        "stages_total_marks": ([(f"{m} marks", [str(m)]) for m in marks], ("marks", "maximum", "total")),
    }


def _evaluate(expected, keywords, docs, texts, years):
    best = {}
    for d in docs:
        t = texts.get(d["key"])
        if not t:
            continue
        cycle_ok = any(str(y) in t for y in years)
        for label, tokens in expected:
            for tok in tokens:
                snip = _find_near(t, tok, keywords)
                if snip:
                    ev = {"value": label, "doc_url": d["final_url"], "doc_type": d["doc_type"],
                          "sha256": d["sha256"], "snippet": snip[:300], "cycle_year_in_doc": cycle_ok}
                    cur = best.get(label)
                    if cur is None or (cur["doc_type"] == "HOMEPAGE" and d["doc_type"] != "HOMEPAGE"):
                        best[label] = ev
                    break
    missing = [l for l, _ in expected if l not in best]
    non_home = [e for e in best.values() if e["doc_type"] != "HOMEPAGE"]
    if not expected:
        status = "NOT_APPLICABLE"
    elif not best:
        status = "NOT_FOUND"
    elif not non_home:
        status = "HOMEPAGE_MENTION_ONLY"
    elif missing or len(non_home) < len(best):
        status = "PARTIAL"
    elif all(e["cycle_year_in_doc"] for e in non_home):
        status = "MATCHED"
    else:
        status = "MATCHED_CYCLE_UNCONFIRMED"
    return {"status": status, "evidence": list(best.values()), "missing_values": missing}


UPLOAD_RE = re.compile(r"[^\n]{0,80}\b\d{1,4}\s*(?:KB|MB)\b[^\n]{0,80}", re.I)


def verify_fields(ex, docs, texts):
    years = _cycle_years(ex)
    result = {k: _evaluate(exp, kw, docs, texts, years) for k, (exp, kw) in _expected(ex).items()}
    observed = []
    for d in docs:
        if d["doc_type"] == "HOMEPAGE":
            continue
        for m in UPLOAD_RE.finditer(texts.get(d["key"], "")):
            s = " ".join(m.group(0).split())
            if re.search(r"photo|signature|thumb", s, re.I):
                observed.append({"doc_url": d["final_url"], "snippet": s[:200]})
    result["documents"] = {
        "status": "EVIDENCE_FOUND_NOT_COMPARED" if observed else "NOT_FOUND",
        "evidence": observed[:15],
        "note": "Upload specs are templated per portal family in the build script; "
                "compare against these snippets by hand.",
    }
    result["registration_steps"] = {
        "status": "TEMPLATED_UNVERIFIED",
        "note": "Step lists are generic templates, not read from a bulletin.",
    }
    return result


# ---------------------------------------------------------------------------
# Date extraction
# ---------------------------------------------------------------------------
MONTH = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_M = (r"(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|"
      r"sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)")
DMY_TXT = re.compile(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?[\s\-/.,]*{_M}\.?[\s\-/.,]*(20\d{{2}})\b", re.I)
MDY_TXT = re.compile(rf"\b{_M}\.?\s+(\d{{1,2}})(?:st|nd|rd|th)?,?\s+(20\d{{2}})\b", re.I)
DMY_NUM = re.compile(r"\b(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2})\b")  # Indian DD-MM-YYYY

# (label regex, start field, end field or None). First match wins; order matters.
LABELS = [(re.compile(rx, re.I), s, e) for rx, s, e in [
    (r"correction (window|period)|edit(ing)? (window|facility)|modification", "application_correction_window_start", "application_correction_window_end"),
    (r"(challenge|objection)", "objection_challenge_window_start", "objection_challenge_window_end"),
    (r"answer key", "answer_key_release", None),
    (r"last date.{0,40}(fee|payment)|fee payment.{0,30}last", "fee_payment_last_date", None),
    (r"last date|closing date|closes on|last day", "application_last_date", None),
    (r"(application|registration).{0,30}(period|begin|start|commence|open)|(start|commencement).{0,20}(application|registration)", "application_form_start", "application_last_date"),
    (r"city intimation|exam(ination)? city", "exam_city_intimation_slip", None),
    (r"admit card|hall ticket|admission certificate|call letter", "admit_card_release", None),
    (r"(date|dates|schedule) of (the )?(exam|examination|cbt|test)|exam(ination)? dates?", "exam_date_start", "exam_date_end"),
    (r"counsell?ing", "counselling_start", "counselling_last_date"),
    (r"document verification", "document_verification", None),
    (r"\bresults?\b", "result_declaration", None),
    (r"joining|reporting|last date of admission", "admission_or_joining_deadline", None),
    (r"notification|advertisement|advt", "official_notification_release", None),
]]
STOP = {"single", "annual", "multi", "exam", "examination", "self", "scheduled", "window",
        "test", "papers", "paper", "mandatory", "offline", "online", "multiple", "windows"}


def _dates_in(line: str) -> list[str]:
    found = []
    for rx, kind in ((DMY_TXT, "dmy"), (MDY_TXT, "mdy"), (DMY_NUM, "num")):
        for m in rx.finditer(line):
            try:
                if kind == "dmy":
                    d, mo, y = int(m[1]), MONTH[m[2][:3].lower()], int(m[3])
                elif kind == "mdy":
                    mo, d, y = MONTH[m[1][:3].lower()], int(m[2]), int(m[3])
                else:
                    d, mo, y = int(m[1]), int(m[2]), int(m[3])
                found.append((m.start(), m.end(), date(y, mo, d).isoformat()))
            except (ValueError, KeyError):
                continue
    found.sort()
    out, last_end = [], -1
    for s, e, iso in found:
        if s >= last_end:
            out.append(iso)
            last_end = e
    return out


def _label_for(line: str, ctx: str):
    for rx, s, e in LABELS:
        if rx.search(line):
            return s, e, "strong"
    for rx, s, e in LABELS:
        if rx.search(ctx):
            return s, e, "weak"
    return None


def _resolve_session(sessions, ctx: str):
    if len(sessions) == 1:
        return sessions[0]
    low = ctx.lower()
    hits = []
    for s in sessions:
        toks = [t for t in re.findall(r"[a-z]+\s*\d+|[a-z]{4,}", s.lower()) if t not in STOP]
        if any(t in low for t in toks):
            hits.append(s)
    return hits[0] if len(hits) == 1 else None


def extract_date_candidates(ex, docs, texts):
    years = _cycle_years(ex)
    this_year = datetime.now().year
    cands = []
    for d in docs:
        t = texts.get(d["key"], "")
        if not t:
            continue
        cycle_ok = any(str(y) in t for y in years)
        lines = [l.strip() for l in t.splitlines() if l.strip()]
        for i, line in enumerate(lines):
            dates = [x for x in _dates_in(line) if this_year - 1 <= int(x[:4]) <= this_year + 2]
            if not dates:
                continue
            ctx = f"{lines[i - 1] if i else ''} {line}"
            hit = _label_for(line, ctx)
            if not hit:
                continue
            start_f, end_f, strength = hit
            if not end_f and len(dates) > 1:
                strength = "weak"  # ambiguous: several dates, single-date label
            assigned = [(start_f, dates[0])]
            if end_f and len(dates) >= 2:
                assigned.append((end_f, dates[1]))
            sess = _resolve_session(ex["sessions"], ctx)
            for field, iso in assigned:
                cands.append({
                    "exam_id": ex["exam_id"], "session": sess, "field": field,
                    "date_value": iso, "doc_url": d["final_url"], "doc_type": d["doc_type"],
                    "doc_sha256": d["sha256"], "fetched_at": d["fetched_at"],
                    "snippet": line[:300], "label_strength": strength,
                    "cycle_year_in_doc": cycle_ok,
                })
    return cands


def resolve_candidates(cands):
    groups = {}
    for c in cands:
        groups.setdefault((c["session"], c["field"]), []).append(c)
    accepted, queued = [], []
    for (sess, field), items in groups.items():
        dates = {c["date_value"] for c in items}
        good = [c for c in items if c["label_strength"] == "strong"
                and c["doc_type"] != "HOMEPAGE" and c["cycle_year_in_doc"]
                and sess is not None and field not in REVIEW_ALWAYS]
        if len(dates) == 1 and good:
            accepted.append(good[0])
            continue
        if len(dates) > 1:
            reason = "CONFLICTING_DATES"
        elif sess is None:
            reason = "SESSION_UNRESOLVED"
        elif field in REVIEW_ALWAYS:
            reason = "FIELD_ALWAYS_REVIEWED"
        else:
            reason = "WEAK_LABEL_OR_HOMEPAGE_OR_CYCLE_UNCONFIRMED"
        queued.extend({**c, "review_reason": reason} for c in items)
    return accepted, queued[:100]


def merge_registry(reg, exam_id, accepted):
    for c in accepted:
        slot = reg.setdefault(exam_id, {}).setdefault(c["session"], {})
        if slot.get(c["field"], {}).get("origin") == "manual":
            continue
        slot[c["field"]] = {
            "date_value": c["date_value"], "origin": "auto",
            "source_url": c["doc_url"], "evidence_snippet": c["snippet"],
            "source_sha256": c["doc_sha256"], "verified_at": c["fetched_at"],
        }


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
def run(exam_ids=None):
    from exams_data import EXAMS_DATA
    report = _load(REPORT_PATH, {})
    registry = _load(REGISTRY_PATH, {})
    review = []
    for ex in EXAMS_DATA:
        eid = ex["exam_id"]
        if exam_ids and eid not in exam_ids:
            continue
        print(f"[{eid}] fetching...")
        docs, texts = gather_documents(ex)
        report[eid] = {"checked_at": _now(), "documents": docs,
                       "fields": verify_fields(ex, docs, texts)}
        accepted, queued = resolve_candidates(extract_date_candidates(ex, docs, texts))
        merge_registry(registry, eid, accepted)
        review = [r for r in review if r["exam_id"] != eid] + queued
        print(f"[{eid}] docs={len(docs)} accepted_dates={len(accepted)} queued={len(queued)}")
        _save(REPORT_PATH, report)       # incremental: survives crashes
        _save(REGISTRY_PATH, registry)
        _save(REVIEW_PATH, review)


# ---------------------------------------------------------------------------
# Helpers used by the build script
# ---------------------------------------------------------------------------
def load_report():
    return _load(REPORT_PATH, {})


def load_date_registry():
    return _load(REGISTRY_PATH, {})


def field_verification(report, exam_id, field):
    f = report.get(exam_id, {}).get("fields", {}).get(field)
    if f:
        return f
    return {"status": "NOT_CHECKED", "evidence": []}


def last_verified(report, exam_id, field):
    """A timestamp only when evidence was actually matched; otherwise None."""
    st = field_verification(report, exam_id, field)["status"]
    if st in ("MATCHED", "MATCHED_CYCLE_UNCONFIRMED", "PARTIAL"):
        return report[exam_id]["checked_at"]
    return None


def date_object(registry, report, exam_id, session, field, fallback_url):
    e = registry.get(exam_id, {}).get(session, {}).get(field)
    if e:
        return {
            "date_value": e["date_value"], "date_type": field,
            "date_status": "Verified from Official Document" if e["origin"] == "auto"
                           else "Verified (manual review)",
            "date_precision": "Day", "official_source_url": e["source_url"],
            "evidence_snippet": e["evidence_snippet"],
            "source_sha256": e.get("source_sha256"),
            "last_verified_at": e["verified_at"], "last_checked_at": e["verified_at"],
        }
    checked = report.get(exam_id, {}).get("checked_at")
    return {
        "date_value": None, "date_type": field,
        "date_status": "Not Found In Fetched Documents" if checked else "Not Checked",
        "date_precision": "Unknown", "official_source_url": fallback_url,
        "evidence_snippet": None, "source_sha256": None,
        "last_verified_at": None, "last_checked_at": checked,
    }


def build_source_records(report, exams):
    """One record per fetched document; supported_fields comes from evidence only."""
    records, by_url = [], {}
    for ex in exams:
        eid = ex["exam_id"]
        rep = report.get(eid)
        if not rep:
            home = ex.get("official_exam_website")
            if home and home not in by_url:
                rec = {"source_id": f"SRC_{len(records) + 1:03d}", "exam_ids": [eid],
                       "source_url": home, "source_title": f"{ex['exam_name']} homepage (not fetched)",
                       "issuing_authority": ex["conducting_authority"],
                       "source_type": "OFFICIAL_HOMEPAGE_UNFETCHED", "http_status": None,
                       "content_sha256": None, "verification_date": None,
                       "supported_fields": [], "verification_status": "UNVERIFIED"}
                by_url[home] = rec
                records.append(rec)
            elif home:
                by_url[home]["exam_ids"].append(eid)
            continue
        for d in rep["documents"]:
            if d["http_status"] != 200:
                continue
            url = d["final_url"]
            supported = sorted(
                fname for fname, f in rep["fields"].items()
                if f["status"] in ("MATCHED", "MATCHED_CYCLE_UNCONFIRMED", "PARTIAL")
                and any(ev["doc_url"] == url for ev in f["evidence"]))
            if url in by_url:
                rec = by_url[url]
                if eid not in rec["exam_ids"]:
                    rec["exam_ids"].append(eid)
                rec["supported_fields"] = sorted(set(rec["supported_fields"]) | set(supported))
                continue
            rec = {"source_id": f"SRC_{len(records) + 1:03d}", "exam_ids": [eid],
                   "source_url": url, "source_title": f"{ex['exam_name']} - {d['doc_type']}",
                   "issuing_authority": ex["conducting_authority"], "source_type": d["doc_type"],
                   "http_status": d["http_status"], "content_sha256": d["sha256"],
                   "verification_date": d["fetched_at"], "supported_fields": supported,
                   "verification_status": "EVIDENCE_LINKED" if supported else "FETCHED_NO_FIELD_EVIDENCE"}
            by_url[url] = rec
            records.append(rec)
    return records


def date_coverage(registry, exams):
    total = populated = 0
    for ex in exams:
        for s in ex["sessions"]:
            for f in DATE_FIELDS:
                total += 1
                populated += f in registry.get(ex["exam_id"], {}).get(s, {})
    return populated, total


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] != "run":
        sys.exit(__doc__)
    run(set(args[1:]) or None)
